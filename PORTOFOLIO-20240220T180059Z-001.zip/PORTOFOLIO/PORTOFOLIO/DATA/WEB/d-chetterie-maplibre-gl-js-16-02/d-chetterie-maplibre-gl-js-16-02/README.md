# Déchetterie maplibre GL JS 16/02

A Pen created on CodePen.io. Original URL: [https://codepen.io/Yanis-Lepesant/pen/gOEqobq](https://codepen.io/Yanis-Lepesant/pen/gOEqobq).

Build a map application with Mapbox GL JS. This guide walks you through all the code that you need to build a store locator.

See the example: [https://docs.mapbox.com//help/tutorials/building-a-store-locator/](https://docs.mapbox.com//help/tutorials/building-a-store-locator/)